module.exports = {
    plugins: [
        ['toc'],
    ],
};
